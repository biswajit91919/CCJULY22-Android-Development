package com.project.wordtopdf.interfaces;

public interface ItemSelectedListener {
    void isSelected(Boolean isSelected, int countFiles);
}