package com.project.wordtopdf.interfaces;

public interface OnTextToPdfInterface {
    void onPDFCreationStarted();
    void onPDFCreated(boolean success);
}
