package com.project.wordtopdf.interfaces;

public interface DataSetChanged {
    void updateDataset();
}
