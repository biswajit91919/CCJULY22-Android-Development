package com.project.wordtopdf.interfaces;

public interface OnItemClickListener {

    void onItemClick(int position);
}
