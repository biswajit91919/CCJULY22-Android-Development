package com.project.wordtopdf.util;

import android.os.AsyncTask;

import java.util.ArrayList;

import com.project.wordtopdf.interfaces.BottomSheetPopulate;

/**
 * AsyncTask used to populate the list of elements in the background
 */
class PopulateBottomSheetListWithExcelFiles extends AsyncTask<Void, Void, ArrayList<String>> {

    private final BottomSheetPopulate mOnLoadListener;
    private final DirectoryUtils mDirectoryUtils;

    PopulateBottomSheetListWithExcelFiles(BottomSheetPopulate listener,
                            DirectoryUtils directoryUtils) {
        mOnLoadListener = listener;
        mDirectoryUtils = directoryUtils;
    }

    @Override
    protected ArrayList<String> doInBackground(Void... voids) {
        return mDirectoryUtils.getAllExcelDocumentsOnDevice();
    }

    @Override
    protected void onPostExecute(ArrayList<String> paths) {
        super.onPostExecute(paths);
        mOnLoadListener.onPopulate(paths);
    }

}